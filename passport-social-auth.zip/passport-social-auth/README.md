install mongodb and provid the path for db/data
create the db name as provided in app.js after the localhost:27017
add the github/linkedin ID and secret and put it inside the _config.js and make sure you put thhose in .gitignore file
Thanks All, 

Shijith Thomas.
